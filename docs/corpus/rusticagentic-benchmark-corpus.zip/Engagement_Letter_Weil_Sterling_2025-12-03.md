ENGAGEMENT LETTER

2025-12-03

Sterling Digital Media LLC
Attn: General Counsel

Re: Engagement for Commercial Litigation Defense

Dear Client:

We are pleased to confirm our engagement by Sterling Digital Media LLC ("Client") to represent you
in connection with Commercial Litigation Defense (the "Matter").

SCOPE OF ENGAGEMENT
Our representation is limited to the Matter described above. Any expansion of scope
requires a written amendment to this letter.

BILLING RATES
Our current standard rates for attorneys who will work on this matter are:
  Partner:   $1,250 per hour
  Associate: $700 per hour
  Paralegal: $350 per hour

These rates are subject to annual adjustment. We will provide 30 days' written
notice of any rate increase.

RETAINER: Upon execution, Client shall pay a retainer of $25,000, which shall be held in our client trust account and applied against fees earned.

BILLING PRACTICES
We bill in one-tenth of an hour increments. Invoices are issued monthly and are
due within 30 days. Unpaid balances accrue interest at 1.5% per month.

TERMINATION
Either party may terminate this engagement at any time by written notice. Upon
termination, Client shall pay all fees and expenses incurred through the date
of termination.

CONFIDENTIALITY
We will maintain the confidentiality of all information you provide to us in
accordance with the applicable rules of professional conduct.

If the foregoing correctly sets forth our understanding, please sign below.

Sincerely,

Weil, Gotshal & Manges LLP
By: _______________________________
Partner

ACCEPTED AND AGREED:
Sterling Digital Media LLC
By: _______________________________
Date: 2025-12-03
